﻿using System;
using System.Web;

namespace TS.BoardIntegration
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string ebeln = HttpUtility.UrlDecode(Request.QueryString["EBELN"]);
            var vendor = ProviderLfa1.GetLfa1FromSap(ebeln);
            if (String.IsNullOrEmpty(vendor.Lifnr))
            {
                form1.Visible = false;
            }
            LIFNR.ReadOnly = LAND1.ReadOnly = NAME1.ReadOnly = ORT01.ReadOnly = PSTLZ.ReadOnly = true;

            LIFNR.Text = vendor.Lifnr;
            LAND1.Text = vendor.Land1;
            NAME1.Text = vendor.Name1;
            ORT01.Text = vendor.Ort01;
            PSTLZ.Text = vendor.Pstlz;
        }
    }
}