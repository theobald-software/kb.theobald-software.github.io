﻿// Theobald Software GmbH, Grass

using System;
using System.Diagnostics;
using ERPConnect;
using ERPConnect.Utils;

namespace TS.BoardIntegration
{
    public class DataProviderConfiguration
    {
        public string License { get; set; }
        public int Config { get; set; }
        public string Host { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Language { get; set; }
        public string Port { get; set; }
    }

    public abstract class ProviderErp
    {
        public static DataProviderConfiguration DataProviderConfiguration { get; set; }

        // Get it to the right place
        static ProviderErp()
        {
            InitCredentials(new DataProviderConfiguration
            {
                Config = 0,
                Host = "ecc.theobald-software.com",
                Language = "EN",
                License = "",
                Password = "",
                Port = "800",
                Username = ""
            });
        }

        public static void InitCredentials(DataProviderConfiguration dataProviderConfiguration)
        {
            DataProviderConfiguration = dataProviderConfiguration;
        }

        #region Connection Routines

        public static R3Connection GetR3Connection()
        {
            // is disposable, should always be used with using
            return new R3Connection(DataProviderConfiguration.Host, DataProviderConfiguration.Config,
                DataProviderConfiguration.Username, DataProviderConfiguration.Password,
                DataProviderConfiguration.Language, DataProviderConfiguration.Port);
        }

        #endregion Connection Routines
    }

    [DebuggerDisplay("LIFNR = {Lifnr}, LAND1 = {Land1}, NAME1 = {Name1}, ORT01 = {Ort01}, PSTLZ = {Pstlz}")]
    public class Lfa1Row
    {
        public string Lifnr { get; set; }
        public string Land1 { get; set; }
        public string Name1 { get; set; }
        public string Ort01 { get; set; }
        public string Pstlz { get; set; }
    }

    public class ProviderLfa1 : ProviderErp
    {
        #region ERPConnect Data Routines

        public static string GetLifnRfromEkko(string ebeln)
        {
            LIC.SetLic(DataProviderConfiguration.License);

            using (var connection = GetR3Connection())
            {
                try
                {
                    connection.Protocol = ClientProtocol.RFC;
                    connection.Open();//false

                    ReadTable table = new ReadTable(connection);

                    table.AddField("LIFNR");
                    table.AddCriteria(String.Format("EBELN = {0}", ebeln));

                    table.TableName = "EKKO";
                    try
                    {
                        table.Run();
                    }
                    catch (Exception)
                    {
                        return String.Empty;
                    }

                    return table.Result.Rows.Count == 0 ? null : table.Result.Rows[0]["LIFNR"].ToString();
                }
                finally
                {
                    if (connection != null && connection.Ping())
                        connection.Close();
                }
            }
        }

        public static Lfa1Row GetLfa1FromSap(string ebeln)
        {
            LIC.SetLic(DataProviderConfiguration.License);
            string lifnr = GetLifnRfromEkko(ebeln);
            Lfa1Row defaultRow = new Lfa1Row
            {
                Lifnr = "",
                Land1 = "LAND1",
                Name1 = "NAME1",
                Ort01 = "ORT01",
                Pstlz = "PSTLZ"
            };

            using (R3Connection connection = GetR3Connection())
            {
                try
                {
                    connection.Protocol = ClientProtocol.RFC;
                    connection.Open();

                    ReadTable table = new ReadTable(connection);
                    table.AddField("LAND1");
                    table.AddField("NAME1");
                    table.AddField("ORT01");
                    table.AddField("PSTLZ");

                    table.AddCriteria(String.Format("LIFNR = '{0}'", lifnr));

                    table.TableName = "LFA1";

                    try
                    {
                        table.Run();
                    }
                    catch (Exception)
                    {
                        return defaultRow;
                    }
                    if (table.Result.Rows.Count == 0)
                    {
                        return defaultRow;
                    }
                    else
                    {
                        var row = table.Result.Rows[0];
                        return new Lfa1Row
                        {
                            Lifnr = lifnr,
                            Land1 = row["LAND1"].ToString(),
                            Name1 = row["NAME1"].ToString(),
                            Ort01 = row["ORT01"].ToString(),
                            Pstlz = row["PSTLZ"].ToString()
                        };
                    }
                }
                finally
                {
                    if (connection != null && connection.Ping())
                        connection.Close();
                }
            }
        }

        #endregion ERPConnect Data Routines
    }
}