﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using LoadDataFromWebService.SapInventoryWebService;
using System.Threading.Tasks;
using System.Text;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace LoadDataFromWebService
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        DataManager dataManager;
        public MainPage()
        {
            this.InitializeComponent();
            dataManager = new DataManager();

            Task result = this.callToWebService();
        }

        public async Task<List<InventoryGetDetailsElement>> callToWebService()
        {
            List<InventoryGetDetailsElement> results = new List<InventoryGetDetailsElement>();
            this.postStatusMessage("Fetching data...");
            try
            {
                results = await this.dataManager.getInventoryList("0200003047", "2014");

                StringBuilder resultString = new StringBuilder("Fetching done. Results:\n");

                foreach (InventoryGetDetailsElement temp in results)
                {
                    System.Diagnostics.Debug.WriteLine("{0} : {1}", temp.Item, temp.Material);
                    resultString.AppendFormat("{0} : {1}\n", temp.Item, temp.Material);
                }
                this.MessageLabel.Text = resultString.ToString();
            }
            catch (Exception ex)
            {
                this.postStatusMessage("Receiving data resulted in an error:\n " + ex.Message);
                throw ex;
            }
            System.Diagnostics.Debug.WriteLine("Fetching done");
            return results;
        }

        public void postStatusMessage(String message)
        {
            this.MessageLabel.Text = message;
            System.Diagnostics.Debug.WriteLine(message);
        }
    }
}
