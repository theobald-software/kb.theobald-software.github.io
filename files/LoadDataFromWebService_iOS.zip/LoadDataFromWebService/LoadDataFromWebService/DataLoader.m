//
//  DataLoader.m
//  LoadDataFromWebService
//
//  Created by David Gries on 19.08.14.
//  Copyright (c) 2014 Theobald Software GmbH. All rights reserved.
//

#import "DataLoader.h"

@implementation DataLoader

-(void) receiveDataFromWeb {
   NSURLConnection *webServiceConnection;
   
   NSURL *webServiceUrl = [[NSURL alloc] initWithString:@"http://*YourServerIp*/_vti_bin/ERPConnectServiceRest.svc/ExecuteXQL"];
   NSMutableURLRequest *request = [[NSMutableURLRequest alloc]
                                   initWithURL:webServiceUrl];
   [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
   
   NSString *authorizationString;
   NSData *authData = [[NSString stringWithFormat:@"%@:%@", @"YourSharePointUsername", @"YourSharePointPassword"]
                       dataUsingEncoding:NSUTF8StringEncoding];
   
   NSString *encodedCredentials = [authData base64EncodedStringWithOptions:0];
   
   authorizationString = [NSString stringWithFormat:@"Basic %@", encodedCredentials];
   
   [request addValue:authorizationString forHTTPHeaderField:@"Authorization"];
   
   [request setHTTPMethod:@"POST"];
   
   NSString *bodyJsonString = @"{\"query\": "
   "\"EXECUTE FUNCTION "
   "'BAPI_MATPHYSINV_GETDETAIL' "
   "EXPORTS "
   "PHYSINVENTORY = '0200003042', FISCALYEAR = '2014' "
   "TABLES "
   "ITEMS INTO @RETVAL "
   "IMPORTS "
   "@RETVAL = HEAD;\" "
   "}";
   
   [request setHTTPBody:[bodyJsonString dataUsingEncoding:NSUTF8StringEncoding]];
   
   webServiceConnection = [[NSURLConnection alloc] initWithRequest:request
                                                          delegate:self
                                                  startImmediately:true];
}

// -------------------------------------------------------------------------------------------------

-(void) connection:(NSURLConnection *) nConnection didReceiveData:(NSData *)nData {
   NSLog(@"In didReceiveData");
   NSError *error;
   NSJSONSerialization *json = [NSJSONSerialization JSONObjectWithData:nData
                                                               options:kNilOptions
                                                                 error:&error];
   if(error != nil) {
      NSLog(@"Error: %@", [error localizedDescription]);
   }
   NSLog(@"Result json: \n%@", json);
   
   // Small addition to pass the data to UI:
   [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionFinished"
                                                       object:json];
}

// -------------------------------------------------------------------------------------------------

-(void) connectionDidFinishLoading:(NSURLConnection *) nConnection {
   NSLog(@"Received data from web");
}

// -------------------------------------------------------------------------------------------------

- (void) connection:(NSURLConnection *) nConnection didFailWithError:(NSError *)error {
   NSLog(@"Connection failed with error");
   // Small addition to pass the data to UI:
   [[NSNotificationCenter defaultCenter] postNotificationName:@"connectionFailed"
                                                       object:[error localizedDescription]];
}

@end