//
//  ViewController.m
//  LoadDataFromWebService
//
//  Created by David Gries on 19.08.14.
//  Copyright (c) 2014 Theobald Software GmbH. All rights reserved.
//

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
   [super viewDidLoad];
   
   [self.view setBackgroundColor:[UIColor colorWithRed:0.3 green:0.4 blue:0.6 alpha:1]];
   
   [self buildSimpleUI];
   
   DataLoader *dl = [[DataLoader alloc] init];
   
   [dl receiveDataFromWeb];
   
   // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
   [super didReceiveMemoryWarning];
   // Dispose of any resources that can be recreated.
}

// -------------------------------------------------------------------------------------------------

// Visual addition for example app

- (void) buildSimpleUI {
   
   self.messageLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 1000, 1000)];
   
   [self.messageLabel setText:@"Loading data..."];
   
   [self.messageLabel sizeToFit];
   
   [self.messageLabel setCenter:self.view.center];
   
   [self.view addSubview:self.messageLabel];
   
   [[NSNotificationCenter defaultCenter] addObserver:self
                                            selector:@selector(updateLabel:)
                                                name:@"connectionFinished"
                                              object:nil];
   
   [[NSNotificationCenter defaultCenter] addObserver:self
                                            selector:@selector(updateLabel:)
                                                name:@"connectionFailed"
                                              object:nil];
}

// -------------------------------------------------------------------------------------------------

- (void) updateLabel:(NSNotification *) nNotification {
   if(self.messageLabel != nil) {
      CGPoint center = self.messageLabel.center;
      
      [self.messageLabel setFrame:CGRectMake(0, 0, 1000, 10000)];
      
      NSString *passedString = [NSString stringWithFormat:@"%@", nNotification.object];
      
      if ([nNotification.name isEqualToString:@"connectionFinished"]) {
         [self.messageLabel setText:@"I have received some data!"];
      }
      else {
         [self.messageLabel setText:passedString];
      }
      
      //[self.messageLabel setText:@"I have received some data!"];
      
      [self.messageLabel sizeToFit];
      
      [self.messageLabel setCenter:center];
   }
}


@end