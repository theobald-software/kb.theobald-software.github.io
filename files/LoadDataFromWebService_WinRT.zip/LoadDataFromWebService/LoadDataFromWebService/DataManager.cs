﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LoadDataFromWebService.SapInventoryWebService;

namespace LoadDataFromWebService
{
    class DataManager
    {
        SAPMMInventoryClient client;
        public DataManager()
        {
            client = new SAPMMInventoryClient();

            // Also add the IP address in line 683 of Reference.cs!
            System.ServiceModel.EndpointAddress address = new System.ServiceModel.EndpointAddress("http://*YourServerIP*/_vti_bin/SAPMMInventory.svc");
            client.Endpoint.Address = address;

            client.ClientCredentials.UserName.UserName = "YourSharePointUsername";
            client.ClientCredentials.UserName.Password = "YourSharePointPassword";
        }

        public async Task<List<InventoryGetDetailsElement>> getInventoryList(string inventoryNumber, string fiscalYear)
        {
            List<InventoryGetDetailsElement> results = new List<InventoryGetDetailsElement>();
            try
            {
                results = await this.client.GetDetailAsync(inventoryNumber, fiscalYear);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Receiving data resulted in an error:\n {0}", ex.Message);
                throw ex;
            }

            
            return results;
        }

    }
}
