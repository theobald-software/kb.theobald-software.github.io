//
//  DataLoader.h
//  LoadDataFromWebService
//
//  Created by David Gries on 19.08.14.
//  Copyright (c) 2014 Theobald Software GmbH. All rights reserved.
//

@interface DataLoader : NSObject

-(void) receiveDataFromWeb;
-(void) connection:(NSURLConnection *) nConnection didReceiveData:(NSData *)nData;
-(void) connectionDidFinishLoading:(NSURLConnection *) nConnection;

@end