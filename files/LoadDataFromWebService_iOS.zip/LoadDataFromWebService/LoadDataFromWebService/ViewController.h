//
//  ViewController.h
//  LoadDataFromWebService
//
//  Created by David Gries on 19.08.14.
//  Copyright (c) 2014 Theobald Software GmbH. All rights reserved.
//

@interface ViewController : UIViewController

@property (nonatomic) UIView *outputView;
@property (nonatomic) UILabel *messageLabel;

@end
