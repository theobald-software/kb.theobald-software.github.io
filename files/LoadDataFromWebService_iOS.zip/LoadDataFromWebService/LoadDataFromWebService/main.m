//
//  main.m
//  LoadDataFromWebService
//
//  Created by David Gries on 19.08.14.
//  Copyright (c) 2014 Theobald Software GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
   @autoreleasepool {
       return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
   }
}
